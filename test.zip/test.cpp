#include <iostream>
#include <cstdlib>
#include<ctime>
#include <string>
#include<graphics.h>
#include<windows.h>
#include<conio.h>
using namespace std;
int Max_tries;
int get_letter(char,string,string&);
int main()
{
    initwindow(1600,1000);
    setcolor(YELLOW);
    settextstyle(DEFAULT_FONT,HORIZ_DIR,6);
    int i,j;
    for(i=10; i<=120; i+=5)
    {
        outtextxy(620,i,"WELCOME");
        delay(210);
        if(i<120)
        {
            cleardevice();
        }
    }
    //for(i=10,j=880; i<=340,j>=360; i+=20,j-=30)
    for(i=120,j=1360; i<=740,j>=760; i+=60,j-=60)
    {
        cleardevice();
        setcolor(YELLOW);
        settextstyle(DEFAULT_FONT,HORIZ_DIR,6);
        outtextxy(620,50,"WELCOME");
        setcolor(WHITE);
        settextstyle(DEFAULT_FONT,HORIZ_DIR,5);
        outtextxy(i,130,"T");
        outtextxy(j,130,"O");
        delay(130);
    }
    for(i=480; i>=220; i-=20)
    {
        cleardevice();
        setcolor(YELLOW);
        settextstyle(DEFAULT_FONT,HORIZ_DIR,6);
        outtextxy(620,50,"WELCOME");
        setcolor(WHITE);
        settextstyle(DEFAULT_FONT,HORIZ_DIR,5);
        outtextxy(720,130,"TO");

        setcolor(YELLOW);
        settextstyle(DEFAULT_FONT,HORIZ_DIR,4);
        outtextxy(525,i,"Hangman Codding Game");
        delay(255);
    }
    settextstyle(DEFAULT_FONT,HORIZ_DIR,3);
    outtextxy(60,350,"->>Press enter for next");
    getch();
    cleardevice();

a:
    settextstyle(DEFAULT_FONT,HORIZ_DIR,3);
    outtextxy(100,60,"press'S' for Start Game ");
    outtextxy(100,100,"Press'Q' for Quit");
    outtextxy(100,140,"Press'I' for Information");
    getch();
    cleardevice();
    if(GetAsyncKeyState('S'))
    {
        settextstyle(SCRIPT_FONT,HORIZ_DIR,5);
        for( i=10; i<=100; i+=10)
        {
            outtextxy(i,100,"Ready");
            delay(120);
            if(i<100)
            {
                cleardevice();
            }
        }
        for(i=10; i<=100; i+=10)
        {
            cleardevice();
            outtextxy(100,100,"Ready");
            outtextxy(230,i,"Stedy");
            delay(120);
        }
        for(i=480; i>=350; i-=20)
        {
            cleardevice();
            outtextxy(100,100,"Ready");
            outtextxy(240,100,"Stedy");
            outtextxy(i,100,"go now");
            delay(120);
        }
        settextstyle(DEFAULT_FONT,HORIZ_DIR,3);
        outtextxy(60,350,"->>Press enter for next");
        getch();
        cleardevice();
    }
    else if(GetAsyncKeyState('Q'))
    {
        settextstyle(DEFAULT_FONT,HORIZ_DIR,5);
        outtextxy(200,200,"Exit");
        getch();
        return 0;
    }
    else if(GetAsyncKeyState('I'))
    {
        settextstyle(DEFAULT_FONT,HORIZ_DIR,2);

        outtextxy(30,20,"* At first guess the secret word.");
        outtextxy(30,60,"* For each turn choose a character.");
        outtextxy(30,100,"* If chosen character is used in");
        outtextxy(30,140,"* The word then choose next character.");
        outtextxy(30,180,"* Else try to choose correct one's");
        outtextxy(30,210,"* You will get 7 chances for easy level,");
        outtextxy(30,240,"* 5 chances for medium and 3 chances for hard level.");
        getch();
        cleardevice();
        goto a;
    }
    else
    {
        goto a;

    }

    string wordset1[]= {"mango","apple","father","mother","brother","ion","app","fog","gym","hug"}; /// 1 st level
    string wordset2[]= {"sunday","monday","tuesday","friday","wednesday","word","huge","july","june","august"}; ///2nd level
    string wordset3[]= {"bangladesh","india","pakistan","afganistan","japan","december","february","january","april","november"}; ///3rd level
    string word;
    int x;
    //srand(time(NULL));///initialization
    int level=1,cnt=0,f=0;
    int total_point=0;
b:
    setbkcolor(RED);
    settextstyle(DEFAULT_FONT,HORIZ_DIR,3);
    outtextxy(30,30,"->>Press 1 for Easy level. ");
    outtextxy(30,60,"->>press 2 for Medium level.");
    outtextxy(30,90,"->>press 3 for hard level ");
    getch();
    setbkcolor(WHITE);
    if(GetAsyncKeyState('1'))
    {
        level=1;
        setbkcolor(RED);
    }
    else if(GetAsyncKeyState('2'))
    {
        level=2;
        setbkcolor(GREEN);
    }
    else if(GetAsyncKeyState('3'))
    {
        level=3;
        setbkcolor(BLUE);
    }
    else
    {
        cleardevice();
        goto b;
    }
    cleardevice();///clear windows
    settextstyle(DEFAULT_FONT,HORIZ_DIR,2);
    if(level==1)
    {
        outtextxy(10,20,"-> Easy level running.");
    }
    else if(level==2)
    {
        outtextxy(10,20,"->Medium level running");
    }
    else
    {
        outtextxy(10,20,"->Hard level running");
    }

    while(cnt<3)
    {
        ///select secret word section ///
        srand(time(NULL));
        x=rand()%10;/// form random value
        if(level==1)
        {
            Max_tries=7;
            word=wordset1[x];
        }
        else if(level==2)
        {
            Max_tries=5;
            word=wordset2[x];
        }
        else
        {
            Max_tries=3;
            word=wordset3[x];
        }

        char charecter;

        string confidential(word.size(),'*');///locking word with *
        int wrong=0;

        int j;///used to denote outstream's y value

        int d;///how much increase or decrease vertics

        if(level==1)
        {
            d=15;
        }
        else if(level==2)
        {
            d=21;
        }
        else
        {
            d=35;
        }


///..............initialization of vertics that is used to draw..................////

        int ax,ay,bx,by,cx,cy,dx,dy,ex,ey,fx,fy,gx,gy,hx,hy,ix,iy,jx,jy,kx,ky,lx,ly,px,py;
        ax=400;
        ay=200;
        ///line(400,200,500,200);/// for ab
        bx=500;
        by=ay;
        ///line(400,200,400,365);///  for ac
        cx=ax;
        cy=ay+165;
        ///line(400,365,650,365);///   for cd
        dx=cx+250;
        dy=cy;
        ///line(450,200,450,240);/// for ef
        ex=ax+50;
        ey=ay;
        fx=ex;
        fy=ey+20;

/// center of head (fx,fy+10) because radius is 10
///ellipse(449,245,0,360,12,6); or ellipse(fx-1,fy+5,0,360,12,6);///roof
///ellipse(449,245,0,360,10,5);or  ellipse(fx-1,fy+5,0,360,10,5);///roof

///arc(555-dx,314,200,340,6);///leap

///line(555-dx,325,555-dx,355);///for body (gh)
        gx=fx+105;
        gy=dy-40;
        hx=gx;
        hy=dy-10;
///line(555-dx,335,542-dx,325);///for pl (left hand)
        px=gx;
        py=gy+10;
        lx=px-13;
        ly=py-10;
///line(555-dx,335,568-dx,325);///for pk (right hand)
        kx=px+13;
        ky=py-10;///ky=ly
///line(555-dx,355,542-dx,365);/// for hi
        ix=hx-13;
        iy=hy+10;
///line(555-dx,355,568-dx,365);/// for hj
        jx=hx+13;
        jy=hy+10;

///...........................................................................////

        while(wrong<Max_tries)
        {
c:
            cleardevice();
            if(level==1)
            {
                //setbkcolor(RED);
                outtextxy(40,10,"-> Easy level runnig...");
                outtextxy(40,30,"Number of maximum wrong guess is: 7");
                bgiout<<"Remaining chance: "<<7-wrong<<endl;
                bgiout<<"Total point: "<<total_point<<endl;
                outstreamxy(40,50);
            }
            else if(level==2)
            {
                //setbkcolor(GREEN);
                outtextxy(40,10,"-> Medium level runnig...");
                outtextxy(40,30,"Number of maximum wrong guess is: 5");
                bgiout<<"Remaining chance: "<<5-wrong<<endl;
                bgiout<<"Total point: "<<total_point<<endl;
                outstreamxy(40,50);
            }
            else
            {
                // setbkcolor(BLUE);
                outtextxy(40,10,"-> Hard level runnig...");
                outtextxy(40,30,"Number of maximum wrong guess is: 3");
                bgiout<<"Remaining chance: "<<3-wrong<<endl;
                bgiout<<"Total point: "<<total_point<<endl;
                outstreamxy(40,50);
            }

            ///draw structure:
            line(ax,ay,bx,by);///line ab
            line(ax,ay,cx,cy);///line ac
            line(cx,cy,dx,dy);///line cd
            line(ex,ey,fx,fy);///line ef
            ellipse(fx-1,fy+5,0,360,12,6);///roof1
            ellipse(fx-1,fy+5,0,360,10,5);///roof2

            line(555-dx,325,555-dx,355);///body (gh)
            circle(555-dx,315,10);///head
            circle(gx,gy-10,10);///head
            circle(552-dx,311,2);///eye
            circle(558-dx,311,2);///eye
            circle(gx-3,(gy-10)-4,2);///eye
            circle(gx+3,(gy-10)-4,2);///eye
            arc(555-dx,314,200,340,6);///leap
            arc(gx,(gy-10)-1,200,340,6);///leap
            line(gx,gy,hx,hy);///body
            line(px,py,lx,ly);///right hand
            line(px,py,kx,ky);///left hand
            line(hx,hy,ix,iy);/// right leg
            line(hx,hy,jx,jy);/// left leg


            j=120;
            bgiout<<"Secret word: "<<confidential<<endl;
            outstreamxy(10,j);
            j+=20;
            bgiout<<"Enter a character: ";
            outstreamxy(10,j);
            getch();
            if(GetAsyncKeyState('A'))
            {
                charecter='a';
                bgiout<<"a"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('B'))
            {
                charecter='b';
                bgiout<<"b"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('C'))
            {
                charecter='c';
                bgiout<<"C"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('D'))
            {
                charecter='d';
                bgiout<<"d"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('E'))
            {
                charecter='e';
                bgiout<<"e"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('F'))
            {
                charecter='f';
                bgiout<<"f"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('G'))
            {
                charecter='g';
                bgiout<<"g"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('H'))
            {
                charecter='h';
                bgiout<<"h"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('I'))
            {
                charecter='i';
                bgiout<<"i"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('J'))
            {
                charecter='j';
                bgiout<<"j"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('K'))
            {
                charecter='k';
                bgiout<<"k"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('L'))
            {
                charecter='l';
                bgiout<<"l"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('M'))
            {
                charecter='m';
                bgiout<<"m"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('N'))
            {
                charecter='n';
                bgiout<<"n"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('O'))
            {
                charecter='o';
                bgiout<<"o"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('P'))
            {
                charecter='p';
                bgiout<<"p"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('Q'))
            {
                charecter='q';
                bgiout<<"q"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('R'))
            {
                charecter='r';
                bgiout<<"r"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('S'))
            {
                charecter='s';
                bgiout<<"s"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('T'))
            {
                charecter='t';
                bgiout<<"t"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('U'))
            {
                charecter='u';
                bgiout<<"u"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('V'))
            {
                charecter='v';
                bgiout<<"v"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('W'))
            {
                charecter='w';
                bgiout<<"w"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('X'))
            {
                charecter='x';
                bgiout<<"x"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('Y'))
            {
                charecter='y';
                bgiout<<"y"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState('Z'))
            {
                charecter='z';
                bgiout<<"z"<<endl;
                outstreamxy(260,j);
            }
            else if(GetAsyncKeyState(VK_LEFT))
            {
                if(fy-d>=220)
                {
                    wrong--;
                    for(i=0; i<=d; i+=2)
                    {

                        cleardevice();
                        if(level==1)
                        {
                            outtextxy(40,10,"-> Easy level runnig...");
                        }
                        else if(level==2)
                        {
                            outtextxy(40,10,"-> Medium level runnig...");

                        }
                        else
                        {
                            outtextxy(40,10,"-> Hard level runnig...");

                        }

                        //bgiout<<"secret word: "<<confidential<<endl;
                        bgiout<<"Back"<<endl;
                        outstreamxy(10,120);
                        ////  kichu line likhini ////

                        line(ax,ay,bx,by);///line ab
                        line(ax,ay,cx,cy);///line ac
                        line(cx,cy,dx,dy);///line cd
                        line(ex,ey,fx,fy-i);///line ef
                        ellipse(fx-1,fy+5-i,0,360,12,6);///roof1
                        ellipse(fx-1,fy+5-i,0,360,10,5);///roof2
                        circle(gx+i,gy-10,10);///head
                        circle(gx-3+i,(gy-10)-4,2);///eye
                        circle(gx+3+i,(gy-10)-4,2);///eye
                        arc(gx+i,(gy-10)-1,200,340,6);///leap
                        line(gx+i,gy,hx+i,hy);///body
                        line(px+i,py,lx+i,ly);///right hand
                        line(px+i,py,kx+i,ky);///left hand
                        line(hx+i,hy,ix+i,iy);/// right leg
                        line(hx+i,hy,jx+i,jy);/// left leg
                        delay(100);
                    }
                    fy-=d;
                    gx+=d;
                    hx+=d;
                    px+=d;
                    lx+=d;
                    kx+=d;
                    ix+=d;
                    jx+=d;
                }
                goto c;
            }
            else
            {
                goto c;
            }

            j+=90;
            if(get_letter(charecter,word,confidential)==0)
            {
                wrong++;
                int i;
                delay(100);
                for(i=0; i<=d; i+=2)
                {

                    cleardevice();
                    if(level==1)
                    {
                        outtextxy(40,10,"-> Easy level runnig...");
                    }
                    else if(level==2)
                    {
                        outtextxy(40,10,"-> Medium level runnig...");

                    }
                    else
                    {
                        outtextxy(40,10,"-> Hard level runnig...");

                    }

                    bgiout<<"secret word: "<<confidential<<endl;
                    bgiout<<"Wrong gess"<<endl;
                    outstreamxy(10,120);
                    ////  kichu line likhini ////

                    line(ax,ay,bx,by);///line ab
                    line(ax,ay,cx,cy);///line ac
                    line(cx,cy,dx,dy);///line cd
                    line(ex,ey,fx,fy+i);///line ef
                    ellipse(fx-1,fy+5+i,0,360,12,6);///roof1
                    ellipse(fx-1,fy+5+i,0,360,10,5);///roof2
                    circle(gx-i,gy-10,10);///head
                    circle(gx-3-i,(gy-10)-4,2);///eye
                    circle(gx+3-i,(gy-10)-4,2);///eye
                    arc(gx-i,(gy-10)-1,200,340,6);///leap
                    line(gx-i,gy,hx-i,hy);///body
                    line(px-i,py,lx-i,ly);///right hand
                    line(px-i,py,kx-i,ky);///left hand
                    line(hx-i,hy,ix-i,iy);/// right leg
                    line(hx-i,hy,jx-i,jy);/// left leg
                    delay(100);
                }
                fy+=d;
                gx-=d;
                hx-=d;
                px-=d;
                lx-=d;
                kx-=d;
                ix-=d;
                jx-=d;
            }
            else
            {
                bgiout<<"Correct gess"<<endl<<"press enter for next"<<endl;
                outstreamxy(10,j);
                getch();
            }
            if(word==confidential)
            {
                cnt++;
                if(level==1)
                {
                    total_point+=3;
                }
                else if(level==2)
                {
                    total_point+=5;
                }
                else if(level==3)
                {
                    total_point+=7;
                }
                bgiout<<"The word is :"<<word<<endl;
                bgiout<<"Congratulations!!\n\n"<<endl;
                bgiout<<"You win the game\n\n"<<endl;
                bgiout<<"If you want to play again\n\n"<<endl;
                bgiout<<"Press Enter "<<endl;
                outstreamxy(10,j+=60);
                getch();
                break;
            }
        }

        if(wrong==Max_tries)
        {

            int i;
            for(i=1; i<=3; i++)
            {
                cleardevice();
                settextstyle(DEFAULT_FONT,HORIZ_DIR,3);
                setcolor(RED);
                outtextxy(20,30,"You have loss the game");
                settextstyle(DEFAULT_FONT,HORIZ_DIR,2);
                setcolor(WHITE);
                bgiout<<"Secret word is "<<word<<"."<<endl;
                outstreamxy(20,70);

                line(ax,ay,bx,by);///line ab
                line(ax,ay,cx,cy);///line ac
                line(cx,cy,dx,dy);///line cd
                line(ex,ey,fx,fy);///line ef
                ellipse(fx-1,fy+5,0,360,12-i,6-i);///roof1
                ellipse(fx-1,fy+5,0,360,10-i,5-i);///roof2
                circle(gx,gy-10,10);///head
                circle(gx-3,(gy-10)-4,2);///eye
                circle(gx+3,(gy-10)-4,2);///eye
                arc(gx,(gy-10)-1,200,340,6);///leap
                line(gx,gy,hx,hy);///body
                line(px,py,lx,ly);///right hand
                line(px,py,kx,ky);///left hand
                line(hx,hy,ix,iy);/// right leg
                line(hx,hy,jx,jy);/// left leg
                delay(100);

            }

            for(i=1; i<=60; i++)
            {
                cleardevice();
                settextstyle(DEFAULT_FONT,HORIZ_DIR,3);
                setcolor(YELLOW);
                outtextxy(20,30,"You have loss the game.");
                delay(10);
                settextstyle(DEFAULT_FONT,HORIZ_DIR,2);
                setcolor(WHITE);
                bgiout<<"Secret word is :"<<word<<"."<<endl;
                outstreamxy(20,70);

                line(ax,ay,bx,by);///line ab
                line(ax,ay,cx,cy);///line ac
                line(cx,cy,dx,dy);///line cd
                line(ex,ey,fx,gy-20-i);///line ef

                circle(gx,gy-10-i,10);///head
                circle(gx-3,(gy-10)-4-i,2);///eye
                circle(gx+3,(gy-10)-4-i,2);///eye
                arc(gx,(gy-10)-1-i,200,340,6);///leap
                line(gx,gy-i,hx,hy-i);///body
                line(px,py-i,lx,ly-i);///right hand
                line(px,py-i,kx,ky-i);///left hand
                line(hx,hy-i,ix,iy-i);/// right leg
                line(hx,hy-i,jx,jy-i);/// left leg
                delay(100);
            }

            break;
        }
        else if(cnt==3&&level<3)
        {
            level++;
            cnt=0;
            wrong=0;
            cleardevice();
            setbkcolor(WHITE);
            if(level==1)
            {
                setbkcolor(RED);

                outtextxy(40,10,"-> Easy level runnig...");
            }
            else if(level==2)
            {
                setbkcolor(GREEN);
                outtextxy(40,10,"-> Medium level runnig...");
            }
            else
            {
                setbkcolor(BLUE);
                outtextxy(40,10,"-> Hard level runnig...");

            }
            getch();
        }
        else if(cnt==3&&level==3)
        {
            cleardevice();
            outtextxy(40,10,"You have successfully overcome all level.");
            outtextxy(40,60,"The Game Is Over.");
            getch();
            return 0;
        }
    }
    cin.ignore();
    cin.get();
    return 0;
}
int get_letter(char guess,string word,string &secret)
{
    int x=word.size();
    int i,match=0;
    for(i=0; i<x; i++)
    {
        if(word[i]==guess)
        {
            secret[i] = guess;///unlock the correct match
            match=1;
        }
    }
    return match;
    getch();
}
